<div class="tabs-nav">
    <div class="tabs-nav-inner">
        <div class="tabs-links<?php echo($current_page == "welcome" ?  " active" : ""); ?>">Welcome</div>
        <div class="tabs-links<?php echo($current_page == "license" ?  " active" : ""); ?>">License</div>
        <div class="tabs-links<?php echo($current_page == "requirements" ?  " active" : ""); ?>">Requirements</div>
        <div class="tabs-links<?php echo($current_page == "database" ?  " active" : ""); ?>">Database</div>
        <div class="tabs-links<?php echo($current_page == "auth" ?  " active" : ""); ?>">Admin Auth</div>
        <div class="tabs-links<?php echo($current_page == "finish" ?  " active" : ""); ?>">Finish</div>
    </div>
</div>